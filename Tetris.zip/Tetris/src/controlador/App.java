package controlador;
/**
 * Clase para iniciar el juego
 */
public class App {

	/**
	 * Main de la aplicacion para iniciar todo
	 * @param args
	 */
	public static void main(String[] args) {
		Control control = new Control();
		control.start();

	}
}
